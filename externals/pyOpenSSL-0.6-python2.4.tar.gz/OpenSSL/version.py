#
# version.py
#
# Copyright (C) AB Strakt 2001-2004, All rights reserved
#
# $Id: version.py,v 1.2 2004/08/13 18:46:04 martin Exp $
#
"""
pyOpenSSL - A simple wrapper around the OpenSSL library
"""
__version__ = '0.6'
